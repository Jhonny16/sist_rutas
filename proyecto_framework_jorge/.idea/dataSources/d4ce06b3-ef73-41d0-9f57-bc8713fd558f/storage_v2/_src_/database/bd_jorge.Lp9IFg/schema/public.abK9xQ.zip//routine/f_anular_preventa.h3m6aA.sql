create function f_anular_preventa(p_preventa integer) returns integer
  language plpgsql
as
$$
declare
		v_productos_vendidos_cursor refcursor;
		v_productos_vendidos_registro record;
		v_estado character;
		
	begin
		begin
			select
				estado
			into
				v_estado
			from
				pre_venta
			where
				id  = p_preventa;

			if v_estado = 'A' then
				RAISE EXCEPTION 'La pre-venta que intenta anular ya ha sido anulada';
			end if;
				
			open v_productos_vendidos_cursor for
				select
					d.id_producto,
					d.cantidad as cantidad
				from
					detalle d
					inner join producto p on ( d.id_producto = p.id )
				where
					d.id_pre_venta = p_preventa;	
			
			loop --Bucle para recorrer cada uno de los registros del cursor
				fetch v_productos_vendidos_cursor into v_productos_vendidos_registro;
				if FOUND then --si aun hay registros
					update
						producto
					set
						cantidad = cantidad + v_productos_vendidos_registro.cantidad
					where
						id= v_productos_vendidos_registro.id_producto;
				else
					exit; --salir de bucle
				end if;
			end loop;

			update 
				pre_venta 
			set 
				estado = 'A' 
			where
				id  = p_preventa;
			
		EXCEPTION
			when others then
				RAISE EXCEPTION '%', SQLERRM;
		end;
		return 1; --Retorna 1 cuando la anulación se hizo con exito
	end;
$$;

alter function f_anular_preventa(integer) owner to postgres;

